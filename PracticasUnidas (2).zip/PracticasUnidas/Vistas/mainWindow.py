import ttkbootstrap as ttk  
from ttkbootstrap.constants import *  
from tabulatorFilters import TabulatorFilters
from tabulatorOperations import TabulatorOperations
from tabulatorImage import TabulatorImage

import cv2  
class MainWindow(ttk.Window):
    def __init__(self):
        super().__init__(themename="cyborg")
        self.title("Procesamiento de Imagenes - Practicas minireto")
        self.state('zoomed')
        self.controlTabulator = None
        self.crear_componentes()
        self.mainloop()

    def crear_componentes(self):
        self.controlTabulator = ttk.Notebook(self)
        tabulatorMain = TabulatorImage(self.controlTabulator)
        tabulatorOperations = TabulatorOperations(self.controlTabulator)
        tabulatorFilters = TabulatorFilters(self.controlTabulator)
        
        self.controlTabulator.add(tabulatorMain, text="Practica Principal")
        self.controlTabulator.add(tabulatorOperations, text="Operaciones con Imagenes")
        self.controlTabulator.add(tabulatorFilters, text="Filtros Espaciales")

        self.controlTabulator.pack(fill=BOTH, expand=True)

ventana = MainWindow()



