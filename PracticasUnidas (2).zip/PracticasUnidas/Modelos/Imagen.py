


class Imagen:
    def __init__(self, id_imagen=None, ruta=None, descripcion=None):
        self.id_imagen = id_imagen
        self.ruta = ruta
        self.descripcion = descripcion

    