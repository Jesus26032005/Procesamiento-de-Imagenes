from Controladores.ImageController import ImageController
from Vistas.mainWindow import MainWindow

vista= MainWindow()